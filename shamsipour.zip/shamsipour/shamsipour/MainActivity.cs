﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Graphics;
using SQLite;
using System.Collections.Generic;
using shamsipour.Resources.Model;

namespace shamsipour
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        LinearLayout stu, teacher;
        private Color color;
        string folder = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
        SQLiteConnection person;
        List<teacher> teachers = new List<teacher>();
        List<studend> studentss = new List<studend>();

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.activity_main);
            stu = FindViewById<LinearLayout>(Resource.Id.student);
            stu.Click += Stu_Click;
            teacher = FindViewById<LinearLayout>(Resource.Id.teacher);
            teacher.Click += Teacher_Click;

            person = new SQLiteConnection(System.IO.Path.Combine(folder, "person.db"));
            person.CreateTable<teacher>();
            person.CreateTable<studend>();
            person.Query<teacher>("insert into teacher (name,lname,course) values"+"("+"name"+"lname"+"course"+")");
            person.Query<studend>("insert into student (name,lname,cours) values"+"("+"name"+"lname"+"course"+")");

        }

        private void Teacher_Click(object sender, System.EventArgs e)
        {
            stu.SetBackgroundColor(Color.ParseColor("#804080"));
            teacher.SetBackgroundColor(Color.ParseColor("#705070"));
            FragmentTransaction transaction = FragmentManager.BeginTransaction();
            transaction.Replace(Resource.Id.layoutorg, new Fragment1());
            transaction.Commit();
        }

        private void Stu_Click(object sender, System.EventArgs e)
        {
            stu.SetBackgroundColor(Color.ParseColor("#705070"));
            teacher.SetBackgroundColor(Color.ParseColor("#804080"));
        }
    }
}